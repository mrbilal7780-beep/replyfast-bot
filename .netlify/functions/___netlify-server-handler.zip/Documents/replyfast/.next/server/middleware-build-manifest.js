globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/ff5641cb2c9fbc95.js",
      "static/chunks/ae6909dcc636811b.js",
      "static/chunks/turbopack-2b54f425c9371a63.js"
    ],
    "/_app": [
      "static/chunks/dc2641acd0c2cd99.js",
      "static/chunks/ae6909dcc636811b.js",
      "static/chunks/turbopack-439998e6f814683b.js"
    ],
    "/_error": [
      "static/chunks/2ed44322f313251d.js",
      "static/chunks/ae6909dcc636811b.js",
      "static/chunks/turbopack-b1b7f5a05535e2bf.js"
    ],
    "/dashboard": [
      "static/chunks/3a0b0f4634b37992.js",
      "static/chunks/ae6909dcc636811b.js",
      "static/chunks/turbopack-7017c880096770af.js"
    ],
    "/login": [
      "static/chunks/1f066325e69cc6d3.js",
      "static/chunks/ae6909dcc636811b.js",
      "static/chunks/turbopack-1159c74d25fdd3d8.js"
    ]
  },
  "devFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];