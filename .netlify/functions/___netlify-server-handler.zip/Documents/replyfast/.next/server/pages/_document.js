var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__d53ccae0._.js")
R.c("server/chunks/ssr/[root-of-the-server]__c19c1553._.js")
R.m(4391)
module.exports=R.m(4391).exports
